import { Injectable, NgZone } from '@angular/core';
import { AuthService } from '@auth0/auth0-angular';
import { HttpClient } from '@angular/common/http';
import { jwtDecode } from 'jwt-decode';

@Injectable({
  providedIn: 'root'
})
export class StatusLoginService {
  isLoginIn: boolean = false;

  constructor(
    public authService: AuthService,
    private ngZone: NgZone,
    private http: HttpClient
  ) {
    this.authService.isAuthenticated$.subscribe((status: boolean) => {
      this.ngZone.run(() => {
        this.isLoginIn = status;

        if (status) {
          this.authService.getAccessTokenSilently().subscribe({
            next: (token: string) => {
              const decoded: any = jwtDecode(token);
              const email = decoded.email;
              localStorage.setItem('access_token', token);
              localStorage.setItem('user_email', email);

              this.sendUserToDatabase(email);
            },
            error: (err) => {
              console.error('❌ Nie udało się pobrać tokena JWT', err);
            }
          });
        }
      });
    });
  }

  sendUserToDatabase(email: string): void {
    const body = {
      email: email,
      role: 'ROLE_USER'
    };

    this.http.post('http://localhost:8080/api/public/createNewUser', body)
      .subscribe({
        next: () => console.log('✅ Użytkownik dodany do bazy.'),
        error: (err) => console.error('❌ Błąd przy dodawaniu użytkownika', err)
      });
  }

  login(): void {
    this.authService.loginWithRedirect();
  }

  logout(): void {
    this.authService.logout({ logoutParams: { returnTo: window.location.origin } });
  }
}
