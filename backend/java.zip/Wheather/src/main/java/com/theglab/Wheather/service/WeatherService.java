package com.theglab.Wheather.service;

import com.theglab.Wheather.model.City;
import com.theglab.Wheather.model.WeatherSnapshot;
import com.theglab.Wheather.repository.CityRepository;
import com.theglab.Wheather.repository.WeatherSnapshotRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class WeatherService {

    @Autowired
    private CityRepository cityRepo;

    @Autowired
    private WeatherSnapshotRepository weatherRepo;

    public WeatherSnapshot getCurrentWeatherById(Long cityId) {
        City city = cityRepo.findById(cityId)
                .orElseThrow(() -> new RuntimeException("City not found"));

        return weatherRepo.findTop10ByCityOrderByRecordedAtDesc(city)
                .stream()
                .findFirst()
                .orElseThrow(() -> new RuntimeException("No weather data available for this city"));
    }

    public WeatherSnapshot getCurrentWeatherByName(String cityName) {
        City city = cityRepo.findByName(cityName)
                .orElseThrow(() -> new RuntimeException("City not found"));

        return weatherRepo.findTop10ByCityOrderByRecordedAtDesc(city)
                .stream()
                .findFirst()
                .orElseThrow(() -> new RuntimeException("No weather data available for this city"));
    }

    public List<WeatherSnapshot> getLast10ByCityId(Long cityId) {
        City city = cityRepo.findById(cityId)
                .orElseThrow(() -> new RuntimeException("City not found"));

        return weatherRepo.findTop10ByCityOrderByRecordedAtDesc(city);
    }

    public List<WeatherSnapshot> getLast10ByCityName(String cityName) {
        City city = cityRepo.findByName(cityName)
                .orElseThrow(() -> new RuntimeException("City not found"));

        return weatherRepo.findTop10ByCityOrderByRecordedAtDesc(city);
    }
}
