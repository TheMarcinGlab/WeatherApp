package com.theglab.Wheather.repository;

import com.theglab.Wheather.model.City;
import com.theglab.Wheather.model.WeatherSnapshot;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface WeatherSnapshotRepository extends JpaRepository<WeatherSnapshot, Long> {
    List<WeatherSnapshot> findTop10ByCityOrderByRecordedAtDesc(City city);
}