package com.theglab.Wheather.controller;

import com.theglab.Wheather.model.WeatherSnapshot;
import com.theglab.Wheather.service.WeatherService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/weather")
@CrossOrigin("*")
public class WeatherController {

    @Autowired
    private WeatherService weatherService;

    @GetMapping("/current/byId")
    public ResponseEntity<WeatherSnapshot> getCurrentById(@RequestParam Long cityId) {
        return ResponseEntity.ok(weatherService.getCurrentWeatherById(cityId));
    }

    @GetMapping("/current/byName")
    public ResponseEntity<WeatherSnapshot> getCurrentByName(@RequestParam String cityName) {
        return ResponseEntity.ok(weatherService.getCurrentWeatherByName(cityName));
    }

    @GetMapping("/history/byId")
    public ResponseEntity<List<WeatherSnapshot>> getHistoryById(@RequestParam Long cityId) {
        return ResponseEntity.ok(weatherService.getLast10ByCityId(cityId));
    }

    @GetMapping("/history/byName")
    public ResponseEntity<List<WeatherSnapshot>> getHistoryByName(@RequestParam String cityName) {
        return ResponseEntity.ok(weatherService.getLast10ByCityName(cityName));
    }
}
